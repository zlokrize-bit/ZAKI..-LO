# ZAKI — تطبيق تحويل Website (zip) → APK

اسم التطبيق الافتراضي **ZAKI**، وجاي معاه أيقونة وشاشة بداية جاهزتين
(`resources/icon.png` و `resources/splash.png`) تتولّد تلقائيًا على أي
APK تبنيه:
- **الأيقونة** (icon.png) → تظهر خارج التطبيق (على شاشة الهاتف الرئيسية).
- **السبلاش** (splash.png) → تظهر جوا التطبيق أول ما يفتح (شاشة التحميل).

إذا بتبي تغيّرها، بدّل الصورتين في مجلد `resources/` بنفس الاسمين
(يفضّل icon.png بمقاس 1024×1024 و splash.png بمقاس 2732×2732).

يرفع المستخدم ملف zip لموقع ثابت (HTML/CSS/JS) والسيرفر يبنيه تلقائيًا
باستخدام [Capacitor](https://capacitorjs.com) ويطلع ملف APK جاهز للتثبيت.

## كيف يشتغل؟

1. الفرونت (`frontend/index.html`) يرفع ملف zip.
2. الباك-إند (`backend/server.js`):
   - يفك ضغط الملف.
   - يسوي مشروع Capacitor مؤقت ويحط ملفاتك بداخله كـ `www/`.
   - يشغّل `npx cap add android` ثم `npx cap sync`.
   - يبني APK عبر Gradle (`assembleDebug`).
   - يرجّع رابط تحميل للـ APK.

## المتطلبات على السيرفر (مهم جدًا)

لازم تجهز هذي قبل التشغيل، وإلا خطوة `gradle_build` بتفشل:

| المتطلب | ملاحظات |
|---|---|
| **Node.js 18+** | لتشغيل السيرفر و npm/npx |
| **Java JDK 17** | Gradle يحتاجه لبناء أندرويد |
| **Android SDK (cmdline-tools)** | `sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"` |
| **متغير البيئة `ANDROID_HOME`** | يشير لمجلد الـ SDK |
| **اتصال إنترنت** | لتحميل حزم npm وGradle أول مرة |

### تثبيت سريع (Ubuntu/Debian)

```bash
sudo apt update
sudo apt install -y openjdk-17-jdk unzip

# Android SDK cmdline-tools
mkdir -p ~/android-sdk/cmdline-tools
cd ~/android-sdk/cmdline-tools
wget https://dl.google.com/android/repository/commandlinetools-linux-latest.zip
unzip commandlinetools-linux-latest.zip -d latest_tmp
mv latest_tmp/cmdline-tools latest
rm -rf latest_tmp commandlinetools-linux-latest.zip

export ANDROID_HOME=~/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

yes | sdkmanager --licenses
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
```

ضيف السطرين `export` بالأعلى إلى `~/.bashrc` عشان تثبت بشكل دائم.

## تشغيل المشروع

```bash
cd backend
npm install
npm start
```

افتح المتصفح على: `http://localhost:4000`

## شكل ملف الـ zip المطلوب

يجب أن يحتوي **جذر** الملف المضغوط على `index.html` مباشرة (أو مجلد واحد بالداخل يحتويها)، مثال:

```
mysite.zip
├── index.html
├── style.css
├── script.js
└── assets/
    └── logo.png
```

## ملاحظات مهمة

- الـ APK الناتج **غير موقّع للنشر على Google Play** (هو build من نوع debug، يصلح للتجربة والتثبيت المباشر Sideload). للنشر الرسمي تحتاج خطوة توقيع (`assembleRelease` + keystore) — أقدر أضيفها لك إذا احتجتها.
- كل عملية بناء تاخذ من دقيقة إلى عدة دقائق حسب سرعة السيرفر (خصوصًا أول مرة لأنه يحمّل Gradle).
- التطبيق الناتج يشتغل كـ WebView يعرض ملفاتك محليًا (بدون حاجة لموقع منشور على الإنترنت).
- هذا مشروع مخصص للاستخدام الشخصي/الداخلي. إذا بتفتحه للعامة (Production)، لازم تضيف: نظام طابور (queue) للبناءات، تنظيف تلقائي للملفات المؤقتة، وحدود استخدام (rate limiting).
