/**
 * webapp-to-apk backend
 * ----------------------
 * يستقبل ملف zip يحتوي كود موقع/ويب أب ثابت (فيه index.html)
 * ثم يبنيه تلقائيًا بواسطة Capacitor + Gradle ليطلع ملف APK جاهز.
 *
 * المتطلبات على السيرفر اللي بيشغّل هذا الكود (راجع README.md):
 *  - Node.js 18+
 *  - Java JDK 17
 *  - Android SDK (cmdline-tools) + متغير البيئة ANDROID_HOME
 *  - اتصال إنترنت (لتحميل حزم Capacitor وGradle أول مرة)
 */

const express = require("express");
const multer = require("multer");
const AdmZip = require("adm-zip");
const cors = require("cors");
const { v4: uuidv4 } = require("uuid");
const { execFile } = require("child_process");
const fs = require("fs");
const path = require("path");
const os = require("os");

const app = express();
const PORT = process.env.PORT || 4000;

// أيقونة وشاشة البداية الافتراضية (تنطبق تلقائيًا على أي تطبيق يُبنى، إلا إذا
// حط المستخدم resources خاصة به داخل الـ zip نفسه بمسار /resources/icon.png)
const DEFAULT_RESOURCES_DIR = path.join(__dirname, "..", "resources");

app.use(cors());
app.use(express.static(path.join(__dirname, "..", "frontend")));

const upload = multer({
  dest: os.tmpdir(),
  limits: { fileSize: 200 * 1024 * 1024 }, // 200MB حد أقصى
  fileFilter: (req, file, cb) => {
    if (path.extname(file.originalname).toLowerCase() !== ".zip") {
      return cb(new Error("الملف لازم يكون .zip"));
    }
    cb(null, true);
  },
});

// حالة كل عملية بناء (بسيط - في الذاكرة، يكفي لخادم واحد)
const jobs = new Map();

function sanitizePackageId(id) {
  // لازم يكون شكل com.example.app
  const clean = (id || "com.zaki.app")
    .toLowerCase()
    .replace(/[^a-z0-9.]/g, "");
  return /^[a-z][a-z0-9]*(\.[a-z][a-z0-9]*)+$/.test(clean)
    ? clean
    : "com.zaki.app";
}

function sanitizeAppName(name) {
  const clean = (name || "ZAKI").replace(/[^\p{L}\p{N} _-]/gu, "").trim();
  return clean.length ? clean.slice(0, 50) : "ZAKI";
}

function run(cmd, args, cwd, onData) {
  return new Promise((resolve, reject) => {
    const child = execFile(cmd, args, {
      cwd,
      maxBuffer: 1024 * 1024 * 50,
      shell: process.platform === "win32",
    });
    let out = "";
    child.stdout?.on("data", (d) => {
      out += d;
      onData?.(d.toString());
    });
    child.stderr?.on("data", (d) => {
      out += d;
      onData?.(d.toString());
    });
    child.on("close", (code) => {
      if (code === 0) resolve(out);
      else reject(new Error(`فشل الأمر: ${cmd} ${args.join(" ")}\n${out}`));
    });
    child.on("error", reject);
  });
}

async function buildApk(jobId, zipPath, appName, packageId) {
  const job = jobs.get(jobId);
  const workDir = path.join(os.tmpdir(), `apkbuild-${jobId}`);
  const wwwDir = path.join(workDir, "www");
  fs.mkdirSync(wwwDir, { recursive: true });

  const log = (msg) => {
    job.log.push(msg);
    if (job.log.length > 500) job.log.shift();
  };

  try {
    job.status = "extracting";
    log("جاري فك ضغط الملف...");
    const zip = new AdmZip(zipPath);
    zip.extractAllTo(wwwDir, true);

    // إذا كان الملف المضغوط فيه مجلد واحد فقط بالداخل، ادخل فيه
    const entries = fs.readdirSync(wwwDir);
    if (
      entries.length === 1 &&
      fs.statSync(path.join(wwwDir, entries[0])).isDirectory()
    ) {
      const inner = path.join(wwwDir, entries[0]);
      const tmp = wwwDir + "_tmp";
      fs.renameSync(inner, tmp);
      fs.rmSync(wwwDir, { recursive: true, force: true });
      fs.renameSync(tmp, wwwDir);
    }

    if (!fs.existsSync(path.join(wwwDir, "index.html"))) {
      throw new Error(
        "ما لقيت index.html داخل الملف المضغوط. تأكد أن الملفات (وليس مجلد فرعي إضافي) هي اللي بجذر الـ zip."
      );
    }

    // تجهيز مجلد resources (أيقونة + splash) لمشروع Capacitor
    job.status = "preparing_icons";
    log("تجهيز الأيقونة وشاشة البداية...");
    const resourcesDest = path.join(workDir, "resources");
    fs.mkdirSync(resourcesDest, { recursive: true });
    // إذا المستخدم حط resources/icon.png و resources/splash.png جوا الـ zip نفسه، نستخدمها
    const userResources = path.join(wwwDir, "resources");
    const sourceResources = fs.existsSync(
      path.join(userResources, "icon.png")
    )
      ? userResources
      : DEFAULT_RESOURCES_DIR;

    for (const f of ["icon.png", "splash.png"]) {
      const src = path.join(sourceResources, f);
      if (fs.existsSync(src)) {
        fs.copyFileSync(src, path.join(resourcesDest, f));
      }
    }

    job.status = "npm_init";
    log("تهيئة مشروع Node...");
    await run("npm", ["init", "-y"], workDir, log);

    job.status = "installing_capacitor";
    log("تثبيت حزم Capacitor (قد تأخذ دقيقة)...");
    await run(
      "npm",
      [
        "install",
        "@capacitor/core",
        "@capacitor/cli",
        "@capacitor/android",
        "@capacitor/assets",
      ],
      workDir,
      log
    );

    job.status = "cap_init";
    log("تهيئة Capacitor...");
    await run(
      "npx",
      ["cap", "init", appName, packageId, "--web-dir=www"],
      workDir,
      log
    );

    job.status = "cap_add_android";
    log("إضافة منصة أندرويد...");
    await run("npx", ["cap", "add", "android"], workDir, log);

    job.status = "generating_icons";
    log("توليد أيقونة التطبيق (خارج) وشاشة البداية (داخل)...");
    await run(
      "npx",
      ["@capacitor/assets", "generate", "--android"],
      workDir,
      log
    );

    job.status = "cap_sync";
    log("مزامنة الملفات مع مشروع أندرويد...");
    await run("npx", ["cap", "sync", "android"], workDir, log);

    job.status = "gradle_build";
    log("بناء APK عبر Gradle (قد تأخذ عدة دقائق أول مرة)...");
    const gradlew =
      process.platform === "win32" ? "gradlew.bat" : "./gradlew";
    await run(
      gradlew,
      ["assembleDebug", "--no-daemon"],
      path.join(workDir, "android"),
      log
    );

    const apkPath = path.join(
      workDir,
      "android",
      "app",
      "build",
      "outputs",
      "apk",
      "debug",
      "app-debug.apk"
    );

    if (!fs.existsSync(apkPath)) {
      throw new Error("ما تولّد ملف APK، راجع السجل لمعرفة السبب.");
    }

    job.status = "done";
    job.apkPath = apkPath;
    log("تم بناء APK بنجاح ✅");
  } catch (err) {
    job.status = "error";
    job.error = err.message;
    log("خطأ: " + err.message);
  } finally {
    fs.rm(zipPath, { force: true }, () => {});
  }
}

// يبدأ عملية التحويل ويرجّع job id فورًا
app.post("/api/convert", upload.single("zipfile"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "ارفع ملف zip." });
  }
  const jobId = uuidv4();
  const appName = sanitizeAppName(req.body.appName);
  const packageId = sanitizePackageId(req.body.packageId);

  jobs.set(jobId, { status: "queued", log: [], error: null, apkPath: null });
  buildApk(jobId, req.file.path, appName, packageId);

  res.json({ jobId });
});

// يتابع حالة عملية البناء (استخدمه polling كل 2-3 ثواني)
app.get("/api/status/:jobId", (req, res) => {
  const job = jobs.get(req.params.jobId);
  if (!job) return res.status(404).json({ error: "job غير موجود" });
  res.json({
    status: job.status,
    error: job.error,
    log: job.log.slice(-20),
    ready: job.status === "done",
  });
});

// تحميل ملف APK الناتج
app.get("/api/download/:jobId", (req, res) => {
  const job = jobs.get(req.params.jobId);
  if (!job || job.status !== "done" || !job.apkPath) {
    return res.status(404).json({ error: "الملف مو جاهز بعد" });
  }
  res.download(job.apkPath, "app-debug.apk");
});

app.listen(PORT, () => {
  console.log(`السيرفر شغّال على http://localhost:${PORT}`);
});
